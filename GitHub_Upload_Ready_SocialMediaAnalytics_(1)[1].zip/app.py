from flask import Flask, render_template, request, redirect, url_for
from textblob import TextBlob
import matplotlib.pyplot as plt
from wordcloud import WordCloud

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/process', methods=['POST'])
def process():
    keyword = request.form['keyword']
    sentiment_counts = {'positive': 10, 'neutral': 5, 'negative': 3}

    labels = sentiment_counts.keys()
    sizes = sentiment_counts.values()
    colors = ['green', 'blue', 'red']
    plt.figure(figsize=(5,5))
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%')
    plt.title('Sentiment Distribution')
    plt.savefig('static/pie_chart.png')
    plt.close()

    text = f"{keyword} brand analysis positive good amazing bad poor neutral social media sentiment"
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)
    wordcloud.to_file("static/wordcloud.png")

    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

if __name__ == '__main__':
    app.run(debug=True)